package hotel;
public class Test {
	
	public static void main(String[] args) {
		homeworkDBtest hb = new homeworkDBtest();
		while(true) {
		hb.selectUsers();
		}
		
	}

}
