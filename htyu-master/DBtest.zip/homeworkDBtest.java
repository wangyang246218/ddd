package hotel;

import java.awt.List;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

class ball{
	private int id;
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "ball [id=" + id + ", name=" + name + "]";
	}
	
}



public class homeworkDBtest {
	@SuppressWarnings("resource")
   public void selectUsers() {
	   String driverClassName = "com.mysql.jdbc.Driver";
	   String url="jdbc:mysql://localhost:3306/ball?useUnicode=true&characterEncoding=utf8";
	   String user="root";
	   String password="YHTyht123";
	   java.sql.Connection conn=null;
	   java.sql.PreparedStatement pstm = null;
	   ResultSet rs = null;
	   String sql=null;
	   try {
		   //��װ����
		   Class.forName(driverClassName);
	   }catch(ClassNotFoundException e) {
		   e.printStackTrace();
	   }
	   try {
		   //���ݿ����Ӷ����൱������
		   System.out.println("�������Ӧ���ֽ�����ز��� 1.���� 2ɾ�� 3.�޸� 4�鿴");
		   Scanner input=new Scanner(System.in);
		   conn=DriverManager.getConnection(url,user,password);
		   int flag= input.nextInt();
		   if(flag==1) {
			   System.out.println("������id");
			   int id=input.nextInt();
			   System.out.println("������name");
			   String names=input.next();
			   String sql2="select * from balllist where nameBall='"+names+"'" ;
			   pstm = conn.prepareStatement(sql2);
			   rs = pstm.executeQuery();//�õ�һ���ѯ���
				if(rs.next()) {
					
					System.out.println( "�ֶ��ظ����޷�����");
				}else {
					 sql="insert into balllist values(' "+id+"','"+names+"')";
					   pstm = conn.prepareStatement(sql);
				   int a=pstm.executeUpdate();
				   if(a>0)
				   System.out.println("success");
				   else {
					   System.out.println("failue");
				   }
				}
			  
				
					
			
			   
		   }
		   if(flag==2) {
			   int ids=input.nextInt();
			  sql="delete  from balllist where idBall='"+ids+"'";
			  pstm = conn.prepareStatement(sql);
			  int a=pstm.executeUpdate();
			   if(a>0)
			   System.out.println("success");
			   else {
				   System.out.println("failue");
			   }
		   }
		   if(flag==3) {
			   System.out.println("�����������޸ĵ��û���");
			   String name1=input.next();
			   System.out.println("�������µ��û���");
			   String name2=input.next();
			   String sql2="select * from balllist where nameBall='"+name2+"'" ;
			   pstm = conn.prepareStatement(sql2);
			   rs = pstm.executeQuery();//�õ�һ���ѯ���
				if(rs.next()) {
					
					System.out.println( "�ֶ��ظ����޷�����");
				}else {
					 sql="update balllist set nameBall='"+name2+"'where nameBall='"+name1+"'";
					   pstm = conn.prepareStatement(sql);
				   int a=pstm.executeUpdate();
				   if(a>0)
				   System.out.println("success");
				   else {
					   System.out.println("failue");
				   }
				}
			 
		   }
		   if(flag==4) {
			   
			   sql="select * from balllist" ;
			   pstm = conn.prepareStatement(sql);
			   rs = pstm.executeQuery();//�õ�һ���ѯ���
			   ArrayList<ball> s = new ArrayList<ball>();
				while(rs.next()) {
					ball b = new ball();
					b.setName(rs.getString("nameBall"));
					b.setId(rs.getInt("idBall"));
					s.add(b);
					
					//Date date = rs.getDate("rtime");//Date����Ҫ�� java.util.Date�������� java.sql.Date��
				}
				System.out.println(s);
		   }
		 
		   
	   }catch(SQLException e) {
		   e.printStackTrace();
	   }
	   finally {
		   if(conn!=null) {
			   try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   if(pstm!=null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			   if(rs!=null) {
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

		   }
	   }
   }
}
