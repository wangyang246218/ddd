package homework;

public class MainTest {
	public static void main(String[] args) {
		Pet[] pets = new Pet[2];
		pets[0]=new Pet("snoopy",3);
		pets[1]=new Pet("bosi",2);
		for(int i=0;i<2;i++) {
			System.out.println(pets[i].toString());
		}
	}

}
