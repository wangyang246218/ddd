package homework;

public class Cat extends Pet{
	public void say() {
		System.out.println("miao miao ...");
	}
	public void run() {
		System.out.println("cat is running");
	}
	public void scratch() {
		System.out.println("i am catch the rats");
	}
	public Cat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cat(String name, int age) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Cat [getName()=" + getName() + ", getAge()=" + getAge() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	

}
