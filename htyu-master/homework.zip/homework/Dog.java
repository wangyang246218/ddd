package homework;

public class Dog extends Pet{
		public void say() {
			System.out.println("wang wang ...");
		}
		public void run() {
			System.out.println("dog is running");
		}
		public void swim() {
			System.out.println("i am swimming");
		}
		public Dog() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Dog(String name, int age) {
			super(name, age);
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "Dog [getName()=" + getName() + ", getAge()=" + getAge() + ", getClass()=" + getClass()
					+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		}
		
}
