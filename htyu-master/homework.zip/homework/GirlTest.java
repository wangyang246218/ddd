package homework;

public class GirlTest {
	public static void main(String[] args) {
		GirlFriend gf = new GirlFriend();
		Dog d = new Dog();
		Cat c = new Cat();
		gf.accept(d);
	}

}
